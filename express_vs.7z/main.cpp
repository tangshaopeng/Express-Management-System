#include<iostream>
#include<cstring>
#include<conio.h >
#include<fstream>
#include<windows.h>
#include"express.h"
#include"manager.h"
#include"picker.h"
#include"date.h"
#include"operate.h"
using namespace std;
int main() {

	vector<Express> s;
	Manager manager;
	Picker picker;
	int choice;
	while (1) {
		operateA();
		cin >> choice;
		if (choice == 1)
		{	
			B:
			string account;
			cout << "�������˺ţ�";
			cin >> account;
			if (account == manager.account)
			{
				char ch;
				while (1)
				{
					char temp[20] ;
					int i = 0;
					system("cls");
					cout << "���������룺";
					ch = _getch();
					while (ch != 13) //�س���asc��
					{
						if (ch == 8 && i > 0)//�˸����asc��
						{
							i--;
							temp[i] = '\0';
							system("cls");//���� �������*
							cout << "���������룺";
							for (int j = 0; j < i; j++)
								cout << "*";

							ch = _getch();

						}
						else
						{
							printf("*");
							temp[i] = ch;
							i++;
							ch = _getch();
						}
					}
					temp[i] = '\0';
					if (strcmp(temp, manager.password) == 0)
					{
						system("cls");
						cout << "��ȷ" << endl << endl;
						break;
					}
					else
					{
						cout << "\n�������!!";
						Sleep(1000);
						ch = _getch();
					}
				}
			}
			else
			{
				cout << "�˺Ŵ��󣡣���";
				Sleep(1000);
				system("cls");
				goto B;
			}
			int choice2;

			cout << "\t\t--------------------------" << endl;
			cout << "\t\t| ��ѡ�����Ĳ�����       |" << endl;
			cout << "\t\t|      1.¼������Ϣ    |" << endl;
			cout << "\t\t|      2.���ҿ����Ϣ    |" << endl;
			cout << "\t\t|      3.ɾ�����        |" << endl;
			cout << "\t\t|      4.���ӿ��        |" << endl;
			cout << "\t\t|      5.�޸Ŀ����Ϣ    |" << endl;
			cout << "\t\t|      6.��ѯδȡ��      |" << endl;
			cout << "\t\t|      7.�޸ĵ�¼����    |" << endl;
			cout << "\t\t|      8.�ر�ϵͳ        |" << endl;
			cout << "\t\t--------------------------" << endl;

			cin >> choice2;
			switch (choice2)
			{
				case 1:manager.Input(s);        break;
				case 2:manager.Search(s);       break;
				case 3:manager.Delete(s);       break;
				case 4:manager.Insert(s);       break;
				case 5:manager.Modify(s);       break;
				case 6:manager.SearchNo(s);     break;
				case 7:manager.change_m();				break;
				case 8:goto A;                  break;
				default:cout << "��������";     break;
			}


		}
		else if (choice == 2)
		{
			picker.Search(s);
		}
		else
			cout << "����ѡ�����󣡣���" << endl;

	}

A:	CDate t;
	string filename;
	int c=10;
	if (t.getMonth()<c)
		if (t.getDay()<c)
			filename = "E:\\" + to_string(t.getYear()) + "0" + to_string(t.getMonth()) + "0" + to_string(t.getDay()) + ".txt";
		else
			filename = "E:\\" + to_string(t.getYear()) + "0" + to_string(t.getMonth()) + to_string(t.getDay()) + ".txt";
	else
		filename = "E:\\" + to_string(t.getYear()) + to_string(t.getMonth()) + to_string(t.getDay()) + ".txt";

	create(filename);
	Out(s, filename);

	return 0;
}
