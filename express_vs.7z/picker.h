#pragma once
#include <iostream>
#include<ctime>
#include<cstdlib>
#include<string>
#include<cstdio>
#include<vector>
#include<string>
#include<ctime>
#include"express.h"
using namespace std;
class Picker {
public:
	string pickerTel;
	Picker() {}
	int Search(vector<Express>& s);
};
