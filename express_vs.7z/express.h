#pragma once
#include <iostream>
#include<ctime>
#include<cstdlib>
#include<cstring>
#include<cstdio>
using namespace std;
class Express {
public:
	string courierNum;
	string company;
	string receiverName;
	string receiverTel;
	string receiverAdd;
	string receiverPost;
	string senderName;
	string senderTel;
	string senderAdd;
	string senderPost;
	string pickNum;
	string state = "δȡ��";
	Express() {}
};
