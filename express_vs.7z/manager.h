#pragma once
#include <iostream>
#include<ctime>
#include<iostream>
#include<cstring>
#include<conio.h >
#include<fstream>
#include<windows.h>
#include<cstdlib>
#include<string>
#include<cstdio>
#include<vector>
#include<string>
#include"express.h"
using namespace std;
class Manager {
public:
	string account = "123456";
	char password[7] = { '1','2','3','4','5','6' };
	void Input(vector<Express>& s);
	int Search(vector<Express>& s);
	int Delete(vector<Express>& s);
	int Modify(vector<Express>& s);
	void Insert(vector<Express>& s);
	void SearchNo(vector<Express>& s);
	void change_m();
};
