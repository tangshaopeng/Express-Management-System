#pragma once
#include<iostream>
#include<cstring>
#include<conio.h >
#include<fstream>
#include<windows.h>
#include"express.h"
#include"manager.h"
#include"picker.h"
#include"date.h"
using namespace std;
void create(string s) {

	ofstream outData(s);
	outData.close();
}
void Out(vector<Express>& s, string filename) {
	int n = s.size();
	fstream outData;
	outData.open(filename, ios::app);
	for (int i = 0; i < n; i++)
	{
		outData << s[i].courierNum << endl;
		outData << s[i].company << endl;
		outData << s[i].receiverName << endl;
		outData << s[i].receiverTel << endl;
		outData << s[i].receiverAdd << endl;
		outData << s[i].receiverPost << endl;
		outData << s[i].senderName << endl;
		outData << s[i].senderTel << endl;
		outData << s[i].senderAdd << endl;
		outData << s[i].senderPost << endl;
		outData << s[i].pickNum << endl;
		outData << s[i].state << endl;
	}
	outData.close();
}
void operateA() {
	cout << endl;
	cout << "\t\t****************************" << endl;
	cout << "\t\t*                          *" << endl;
	cout << "\t\t* �������������ݣ�         *" << endl;
	cout << "\t\t*                          *" << endl;
	cout << "\t\t*   1.������Ա   2.ȡ����  *" << endl;
	cout << "\t\t*                          *" << endl;
	cout << "\t\t****************************" << endl;
}

